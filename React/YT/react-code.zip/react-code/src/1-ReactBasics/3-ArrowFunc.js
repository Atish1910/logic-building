import React from "react";

// Arrow Function Expression
const ArrowFunc = (props) => {
  return (
    <div>
      <h1>{props.name}</h1>
    </div>
  );
};
export default ArrowFunc;

