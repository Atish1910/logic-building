
import React from "react";

// CodeSplit.js: Component
const CodeSplit = () => {
  return <div>My component!</div>;
};

export default CodeSplit;

