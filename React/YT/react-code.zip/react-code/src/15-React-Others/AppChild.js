
import React from "react";

const AppChild = (props) => {
  return <h1>Hello, {props.name}!</h1>;
};

export default AppChild;


