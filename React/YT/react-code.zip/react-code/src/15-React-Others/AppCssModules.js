
  import React from 'react';
  import styles from './styles.module.css';
  
  const AppCssModules = () => {
    return (
      <div>
        <h1 className={styles.myAppTitle}>CSS Modules</h1>
      </div>
    );
  };
  
  export default AppCssModules;
  