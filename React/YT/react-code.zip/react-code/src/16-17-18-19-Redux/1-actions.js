
// actions.js

// Action creator function
export const increment = () => ({
  type: 'INCREMENT' // Action type
});

// Action creator function
export const decrement = () => ({
  type: 'DECREMENT' // Action type
});


