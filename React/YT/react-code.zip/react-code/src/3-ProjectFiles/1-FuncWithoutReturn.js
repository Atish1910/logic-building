import React from "react";

const FuncWithoutReturn = () => {
  //   return (
  //     <div>
  //       <h1>Interview Happy</h1>
  //     </div>
  //   );

  console.log("No Return");
};

export default FuncWithoutReturn;

