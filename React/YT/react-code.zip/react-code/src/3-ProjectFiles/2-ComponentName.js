import React from "react";

const DifferentComponentName = () => {
  return (
    <div>
      <h1>Interview Happy</h1>
    </div>
  );
};

export default DifferentComponentName;


