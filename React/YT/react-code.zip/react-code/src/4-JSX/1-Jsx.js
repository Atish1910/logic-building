import React from "react";

function App() {
  return (
    <div className="App">
      <h1>Hello!</h1>
      <p>Happy</p>
    </div>
  );
}
