import React from "react";

function App() {
  return (
    <>
      <div>Interview</div>
      <div>Happy</div>
    </>
  );
}
