import React, { Component } from 'react';

class AppClass extends Component {
  render() {
    return <h1>Interview Happy</h1>;
  }
}

export default AppClass;



